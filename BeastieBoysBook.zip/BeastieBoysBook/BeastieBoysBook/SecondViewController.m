//
//  SecondViewController.m
//  BeastieBoysBook
//
//  Created by  杨兴  on 15/9/22.
//  Copyright (c) 2015年 yx. All rights reserved.
//

#import "SecondViewController.h"
#import "JHOpenidSupplier.h"
#import "JHAPISDK.h"
#import "LastViewController.h"
#import "UIImageView+WebCache.h"
@interface SecondViewController ()


@end

@implementation SecondViewController

@synthesize str;
@synthesize maps;

- (instancetype)init{
    
   
    
    UICollectionViewFlowLayout *flow = [[UICollectionViewFlowLayout alloc] init];
    flow.minimumLineSpacing = 10;
    flow.minimumInteritemSpacing = 10;
    CGFloat width = [[UIScreen mainScreen] bounds].size.width / 2 - 3*10;
    flow.itemSize = CGSizeMake(width,width);
    flow.sectionInset = UIEdgeInsetsMake(0, 20, 10, 20);
    
    
//    UICollectionReusableView *view = [UICollectionView
//                                      dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionFooter
//                                      withReuseIdentifier:TheReuseID
//                                      forIndexPath:indexPath];
//    
    self = [self initWithCollectionViewLayout:flow];
    if (self) {
        
        // insert code here...
    }
    return self;
}


- (void)reloadDates
{
    //    ***************** LIFE ***************
    //    /*IP*/
    str = [str stringByReplacingOccurrencesOfString:@" " withString:@"+"];
    NSLog(@"strrr%@",str);
    NSString *path = @"http://japi.juhe.cn/comic/chapter";
    NSString *api_id = @"163";
    NSString *method = @"GET";
    NSDictionary *param = @{@"comicName":str, @"skip": @0};
    JHAPISDK *juheapi = [JHAPISDK shareJHAPISDK];
    
    [juheapi executeWorkWithAPI:path
                          APIID:api_id
                     Parameters:param
                         Method:method
                        Success:^(id responseObject){
                            NSLog(@"%@",responseObject);
                            
                            NSDictionary* dic  = responseObject;
                            _array= [[dic objectForKey:@"result"] objectForKey:@"chapterList"];
                            NSLog(@"%@",_array);
                            
                            self.collectionView.reloadData;
                            
                            
                        } Failure:^(NSError *error) {
                            NSLog(@"error:   %@",error.description);
                        }];
}

- (void)viewDidLoad {
    self.title= str;
    
    self.view.backgroundColor = [UIColor whiteColor];
    _array = [NSMutableArray array];
    
    
    [super viewDidLoad];
    
    //确定是水平滚动，还是垂直滚动
    UICollectionViewFlowLayout *flowLayout=[[UICollectionViewFlowLayout alloc] init];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
    
    self.collectionView=[[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) collectionViewLayout:flowLayout];
    self.collectionView.dataSource=self;
    self.collectionView.delegate=self;
    [self.collectionView setBackgroundColor:[UIColor clearColor]];
    
    //注册Cell，必须要有
    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"UICollectionViewCell"];
    
    [self.collectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HeaderView"];
    
    //代码控制header和footer的显示
    UICollectionViewFlowLayout *collectionViewLayout = (UICollectionViewFlowLayout *)self.collectionView.collectionViewLayout;
    collectionViewLayout.headerReferenceSize = CGSizeMake(self.view.frame.size.width, self.view.frame.size.height/3);
    [self.view addSubview:self.collectionView];
    [self reloadDates];
}

- (UICollectionViewFlowLayout *) flowLayout{
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    //各属性设置
    flowLayout.headerReferenceSize = CGSizeMake(self.view.frame.size.width, self.view.frame.size.height/3);  //设置head大小
    return flowLayout;
}
- (UICollectionReusableView *) collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionReusableView *reusableview = nil;
    
    if (kind == UICollectionElementKindSectionHeader)
    {
        UICollectionReusableView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HeaderView" forIndexPath:indexPath];
        
        
        reusableview = headerView;
    }
    
    
    UIImageView *headview = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, (self.view.frame.size.width/2), self.view.frame.size.height/3)];
    
    headview.layer.cornerRadius = 8;
    headview.layer.masksToBounds = YES;
    
    NSLog(@"%@",[_topItem objectForKey:@"coverImg"]);
    
    NSURL *photourl = [NSURL URLWithString:[_topItem objectForKey:@"coverImg"]];
    
    [headview sd_setImageWithURL:photourl];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake((self.view.frame.size.width)/2, 0, (self.view.frame.size.width)/2, (self.view.frame.size.height/3)/3)];
    label.textColor = [UIColor grayColor];
    label.font = [UIFont fontWithName:@"Helvetica" size:15];
//    label.textAlignment = UITextAlignmentCenter;
    label.backgroundColor = [UIColor groupTableViewBackgroundColor];
    label.text = [@"类型" stringByAppendingString:[_topItem objectForKey:@"type"]];
    label.layer.borderColor=[UIColor whiteColor].CGColor;
    label.layer.borderWidth=1;
    
    UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake((self.view.frame.size.width)/2, (self.view.frame.size.height/3)/3, (self.view.frame.size.width)/2, (self.view.frame.size.height/3)/3)];
    label2.textColor = [UIColor grayColor];
    label2.font = [UIFont fontWithName:@"Helvetica" size:15];
    //label2.textAlignment = UITextAlignmentCenter;
    label2.backgroundColor = [UIColor groupTableViewBackgroundColor];
    label2.text = [_topItem objectForKey:@"area"];
    label2.layer.borderColor=[UIColor whiteColor].CGColor;
    label2.layer.borderWidth=1;
    
    UILabel *label3 = [[UILabel alloc] initWithFrame:CGRectMake((self.view.frame.size.width)/2, (self.view.frame.size.height/3)/3*2, (self.view.frame.size.width)/2, (self.view.frame.size.height/3)/3)];
    label3.textColor = [UIColor grayColor];
    label3.font = [UIFont fontWithName:@"Helvetica" size:15];
    //label2.textAlignment = UITextAlignmentCenter;
    label3.backgroundColor = [UIColor groupTableViewBackgroundColor];
    //[_topItem objectForKey:@"lastUpdate"]
    label3.text = [@"最后更新" stringByAppendingString:[NSString stringWithFormat:@"%d", [_topItem objectForKey:@"lastUpdate"]]];  ;
    //label3.layer.borderColor = [UIColor  whiteColor];
    label3.layer.borderColor=[UIColor whiteColor].CGColor;
    label3.layer.borderWidth=1;
    
    
    [reusableview addSubview:headview];
    [reusableview addSubview:label];
    [reusableview addSubview:label2];
    [reusableview addSubview:label3];
    reusableview.backgroundColor = [UIColor whiteColor];
    
    return reusableview;
}

//}
//定义展示的UICollectionViewCell的个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _array.count;
}

//定义展示的Section的个数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

//每个UICollectionView展示的内容
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * CellIdentifier = @"UICollectionViewCell";
    UICollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    
//    cell.layer.borderColor=[UIColor darkGrayColor].CGColor;
//    cell.layer.borderWidth=1;
    //cell.window.frame.size
    
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height/8)];
    label.textColor = [UIColor grayColor];
    label.font = [UIFont fontWithName:@"Helvetica" size:20];
    label.textAlignment = UITextAlignmentCenter;
    label.backgroundColor = [UIColor groupTableViewBackgroundColor];
    
    
    NSMutableDictionary *map =  _array[indexPath.row];
    [map objectForKey:@"name"];
    label.text = [NSString stringWithFormat:@"  %@",[map objectForKey:@"name"]];
    
    
    
    for (id subView in cell.contentView.subviews) {
        [subView removeFromSuperview];
    }
    
    
    //[cell.contentView addSubview:headview];
    [cell.contentView addSubview:label];
    cell.contentView.backgroundColor = [UIColor whiteColor];
    return cell;
}

#pragma mark --UICollectionViewDelegateFlowLayout

//定义每个Item 的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(self.view.frame.size.width, self.view.frame.size.height/8);
}

//定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}

#pragma mark --UICollectionViewDelegate

//UICollectionView被选中时调用的方法
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell * cell = (UICollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
    //临时改变个颜色，看好，只是临时改变的。如果要永久改变，可以先改数据源，然后在cellForItemAtIndexPath中控制。（和UITableView差不多吧！O(∩_∩)O~）
    cell.backgroundColor = [UIColor grayColor];
    NSLog(@"item======%d",indexPath.item);
    NSLog(@"row=======%d",indexPath.row);
    NSLog(@"section===%d",indexPath.section);
    NSMutableDictionary *map =  _array[indexPath.row];
    NSLog(@"内容 %@",[map objectForKey:@"name"]);
    
    NSMutableDictionary *param =[NSMutableDictionary dictionaryWithObjectsAndKeys:str,@"comicName",[map objectForKey:@"id"],@"id", nil];
    
    LastViewController *next =[[LastViewController alloc]init];
    [next setMaps:param];
    [self.navigationController pushViewController:next animated:YES];
    
}

//返回这个UICollectionView是否可以被选择
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}





@end
