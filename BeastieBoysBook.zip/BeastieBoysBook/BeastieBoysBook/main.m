//
//  main.m
//  BeastieBoysBook
//
//  Created by  杨兴  on 15/9/20.
//  Copyright (c) 2015年 yx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
