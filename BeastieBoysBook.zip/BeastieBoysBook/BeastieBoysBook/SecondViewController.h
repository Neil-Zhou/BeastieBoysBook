//
//  SecondViewController.h
//  BeastieBoysBook
//
//  Created by  杨兴  on 15/9/22.
//  Copyright (c) 2015年 yx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UICollectionViewController<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property NSString * str;

@property NSMutableDictionary *maps;

@property NSMutableArray *array;

@property (strong, nonatomic)UICollectionView *collectionView;

@property NSMutableDictionary* topItem;

@end
