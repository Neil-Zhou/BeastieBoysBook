//
//  MyViewController.h
//  BeastieBoysBook
//
//  Created by  杨兴  on 15/9/20.
//  Copyright (c) 2015年 yx. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "XBScrollPageController/Controller/XBScrollPageController.h"
//#import "XBScrollPageController/XBScrollPageController/Controller/XBScrollPageController.h"
#import "XBScrollPageController.h"
@interface MyViewController : XBScrollPageController

@property NSMutableArray *dic3;

@end
