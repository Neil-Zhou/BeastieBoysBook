//
//  BookTypeViewController.m
//  BeastieBoysBook
//
//  Created by  杨兴  on 15/9/23.
//  Copyright (c) 2015年 yx. All rights reserved.
//

#import "BookTypeViewController.h"
#import "SecondViewController.h"
#import "JHOpenidSupplier.h"
#import "JHAPISDK.h"
#import "LastViewController.h"
#import "XBConst.h"
#import "OneViewController.h"

@interface BookTypeViewController ()

@end

@implementation BookTypeViewController

//@synthesize str;
//@synthesize maps;

- (instancetype)init{
    
    UICollectionViewFlowLayout *flow = [[UICollectionViewFlowLayout alloc] init];
    flow.minimumLineSpacing = 10;
    flow.minimumInteritemSpacing = 10;
    CGFloat width = [[UIScreen mainScreen] bounds].size.width / 2 - 3*10;
    flow.itemSize = CGSizeMake(width,width);
    flow.sectionInset = UIEdgeInsetsMake(0, 20, 10, 20);
    
    self = [self initWithCollectionViewLayout:flow];
    if (self) {
        // insert code here...
    }
    return self;
}


- (void)reloadDates
{
    //    ***************** LIFE ***************
    //    /*IP*/
    NSString *path = @"http://japi.juhe.cn/comic/category";
    NSString *api_id = @"163";
    NSString *method = @"GET";
    NSDictionary *param = @{};
    JHAPISDK *juheapi = [JHAPISDK shareJHAPISDK];
    
    [juheapi executeWorkWithAPI:path
                          APIID:api_id
                     Parameters:param
                         Method:method
                        Success:^(id responseObject){
                            
                            NSDictionary* dic  = responseObject;
                            _array= [dic objectForKey:@"result"];
                            NSLog(@"%@",_array);
                            
                            self.collectionView.reloadData;
                            
                            
                        } Failure:^(NSError *error) {
                            NSLog(@"error:   %@",error.description);
                        }];
}

- (void)viewDidLoad {
    
    self.view.backgroundColor = [UIColor whiteColor];
    _array = [NSMutableArray array];
    //    [_arrays addObject:@"你好"];
    //    [_arrays addObject:@"你好"];
    //    [_arrays addObject:@"你好"];
    
    
    [super viewDidLoad];
    
    //确定是水平滚动，还是垂直滚动
    UICollectionViewFlowLayout *flowLayout=[[UICollectionViewFlowLayout alloc] init];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
    [flowLayout setSectionInset:UIEdgeInsetsMake(-65.0f, 1.0f, 0.0f, 0.0f)];
    self.collectionView=[[UICollectionView alloc] initWithFrame:CGRectMake(0, 64, 320, 200) collectionViewLayout:flowLayout];
    self.collectionView.dataSource=self;
    self.collectionView.delegate=self;
    [self.collectionView setBackgroundColor:[UIColor clearColor]];
    
    //注册Cell，必须要有
    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"UICollectionViewCell"];
    
    [self.view addSubview:self.collectionView];
    
    //    [self delArray];
    [self reloadDates];
}

//}
//定义展示的UICollectionViewCell的个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _array.count;
}

//定义展示的Section的个数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

//每个UICollectionView展示的内容
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * CellIdentifier = @"UICollectionViewCell";
    UICollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height/4)];
    label.textColor = [UIColor grayColor];
    label.font = [UIFont fontWithName:@"Helvetica" size:20];
    label.textAlignment = UITextAlignmentCenter;
    label.backgroundColor = [UIColor groupTableViewBackgroundColor];
    NSString *str =  _array[indexPath.row];
    label.text = str;
    
    
    
    for (id subView in cell.contentView.subviews) {
        [subView removeFromSuperview];
    }
    
    
    //[cell.contentView addSubview:headview];
    [cell.contentView addSubview:label];
    cell.contentView.backgroundColor = [UIColor whiteColor];
    cell.layer.borderColor=[UIColor whiteColor].CGColor;
    cell.layer.borderWidth=1;
    
    return cell;
}

#pragma mark --UICollectionViewDelegateFlowLayout

//定义每个Item 的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(self.view.frame.size.width, self.view.frame.size.height/4);
}

//定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0, 0, 0, 0);
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    return 0.0f;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 0.0f;
}

#pragma mark --UICollectionViewDelegate

//UICollectionView被选中时调用的方法
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell * cell = (UICollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
    //临时改变个颜色，看好，只是临时改变的。如果要永久改变，可以先改数据源，然后在cellForItemAtIndexPath中控制。（和UITableView差不多吧！O(∩_∩)O~）
    cell.backgroundColor = [UIColor grayColor];
//    NSLog(@"item======%d",indexPath.item);
//    NSLog(@"row=======%d",indexPath.row);
//    NSLog(@"section===%d",indexPath.section);
//    
//    NSLog(@"%@",_array[indexPath.row]);
    
    OneViewController *o=[[OneViewController alloc]init];
    NSMutableDictionary *map= [NSMutableDictionary dictionary];
    [map setObject:_array[indexPath.row] forKey:@"type"];
    [o setMap:map];

    [self.navigationController pushViewController:o animated:YES];
    
}

//返回这个UICollectionView是否可以被选择
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
- (void)dealloc
{
    XBLog(@"XBCollectionViewController delloc");
    
}

- (void)setXBParam:(NSString *)XBParam
{
    _XBParam = XBParam;
    XBLog(@"XBCollectionViewController received param === %@",XBParam);
}

@end
