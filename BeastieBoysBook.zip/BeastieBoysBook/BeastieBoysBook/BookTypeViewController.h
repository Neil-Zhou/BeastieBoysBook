//
//  BookTypeViewController.h
//  BeastieBoysBook
//
//  Created by  杨兴  on 15/9/23.
//  Copyright (c) 2015年 yx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BookTypeViewController : UICollectionViewController<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property NSMutableArray *array;

@property (nonatomic,copy) NSString *XBParam;
@property (strong, nonatomic)UICollectionView *collectionView;
@end
