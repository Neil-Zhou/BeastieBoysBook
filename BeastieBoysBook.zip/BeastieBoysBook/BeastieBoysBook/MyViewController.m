//
//  MyViewController.m
//  BeastieBoysBook
//
//  Created by  杨兴  on 15/9/20.
//  Copyright (c) 2015年 yx. All rights reserved.
//

#import "MyViewController.h"
#import "OneViewController.h"
#import "BookTypeViewController.h"
#import "SeachViewController.h"
#import "JHOpenidSupplier.h"
#import "JHAPISDK.h"
#import "XBConst.h"

@interface MyViewController ()



@end



@implementation MyViewController

@synthesize dic3;


//重载init方法
- (instancetype)init
{
    
    dic3 =[NSMutableArray array];
    
    [[JHOpenidSupplier shareSupplier] registerJuheAPIByOpenId:@"JHb785bc5686ab139b77e5ea837d7f1551"];

    if (self = [super initWithTagViewHeight:49])
    {
        
    }
    return self;
}




- (void)viewDidLoad {
    NSLog(@"%@",dic3);
    [super viewDidLoad];
    self.title = @"兔崽子漫画";
    
    //设置自定义属性
    self.tagItemSize = CGSizeMake(110, 49);
    
    self.backgroundColor = [UIColor whiteColor];
    
    NSArray *titleArray = @[
                            @"列表",
                            @"分类",
                            @"搜索"
                            ];
    
    NSArray *classNames = @[
                            [OneViewController class],
                            [BookTypeViewController class],
                            [SeachViewController class]
                            ];
    
    NSArray *params = @[
                        @"XBParamImage",
                        @"TableView",
                        @"CollectionView"
                        ];
    
    
    [self reloadDataWith:titleArray andSubViewdisplayClasses:classNames withParams:params];
    
    
}




@end
