//
//  OneViewController.m
//  BeastieBoysBook
//
//  Created by  杨兴  on 15/9/20.
//  Copyright (c) 2015年 yx. All rights reserved.
//

#import "OneViewController.h"
#import "XBConst.h"
#import "JHOpenidSupplier.h"
#import "JHAPISDK.h"
#import "UIImageView+WebCache.h"
#import "SecondViewController.h"


@interface OneViewController ()


@end

@implementation OneViewController



- (instancetype)init{
       UICollectionViewFlowLayout *flow = [[UICollectionViewFlowLayout alloc] init];
    flow.minimumLineSpacing = 10;
    flow.minimumInteritemSpacing = 10;
    CGFloat width = [[UIScreen mainScreen] bounds].size.width / 2 - 3*10;
    flow.itemSize = CGSizeMake(width,width);
    flow.sectionInset = UIEdgeInsetsMake(0, 20, 10, 20);
    
    self = [self initWithCollectionViewLayout:flow];
    if (self) {
        // insert code here...
    }
    return self;
}


- (void)reloadDates
{
    //    ***************** LIFE ***************
    //    /*IP*/
    NSString *path = @"http://japi.juhe.cn/comic/book";
    NSString *api_id = @"163";
    NSString *method = @"GET";
    NSDictionary *param = nil;
    
    if (_map!= nil) {
        if ([_map objectForKey:@"name"]!= nil) {
            param =@{@"name":[_map objectForKey:@"name"]};
            self.title = [_map objectForKey:@"name"];
        }else{
            param =@{@"type":[_map objectForKey:@"type"]};
            self.title = [_map objectForKey:@"type"];
        }
            }
    JHAPISDK *juheapi = [JHAPISDK shareJHAPISDK];
    
    [juheapi executeWorkWithAPI:path
                          APIID:api_id
                     Parameters:param
                         Method:method
                        Success:^(id responseObject){
                            
                            NSDictionary* dic  = responseObject;
                            _arrays= [[dic objectForKey:@"result"] objectForKey:@"bookList"];
                         
                            self.collectionView.reloadData;
                            
                            
                        } Failure:^(NSError *error) {
                            NSLog(@"error:   %@",error.description);
                        }];
}

- (void)viewDidLoad {
    [self.navigationController.navigationBar setBarTintColor:[UIColor groupTableViewBackgroundColor]];//设置navigationbar的颜色  
    self.view.backgroundColor = [UIColor whiteColor];
    
    _arrays = [NSMutableArray array];
    

    [super viewDidLoad];
    
    //确定是水平滚动，还是垂直滚动
    UICollectionViewFlowLayout *flowLayout=[[UICollectionViewFlowLayout alloc] init];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];

    
    self.collectionView=[[UICollectionView alloc] initWithFrame:CGRectMake(0, 64, 320, 200) collectionViewLayout:flowLayout];
    self.collectionView.dataSource=self;
    self.collectionView.delegate=self;
    [self.collectionView setBackgroundColor:[UIColor clearColor]];
    
    //注册Cell，必须要有
    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"UICollectionViewCell"];
    
    [self.view addSubview:self.collectionView];
    
    
    
//    [self delArray];
    [self reloadDates];
}

//}
//定义展示的UICollectionViewCell的个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _arrays.count;
}

//定义展示的Section的个数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

//每个UICollectionView展示的内容
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * CellIdentifier = @"UICollectionViewCell";
    UICollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    
    cell.layer.borderColor=[UIColor darkGrayColor].CGColor;
    cell.layer.borderWidth=1;

    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, cell.frame.size.width, cell.frame.size.height/8)];
    label.textColor = [UIColor whiteColor];
    label.font = [UIFont fontWithName:@"Helvetica" size:15];
    label.backgroundColor = [UIColor groupTableViewBackgroundColor];
    label.textColor = [UIColor grayColor];
    
    NSMutableDictionary *map =  _arrays[indexPath.row];
    [map objectForKey:@"name"];
    label.text = [NSString stringWithFormat:@"  %@",[map objectForKey:@"name"]];
    
    UIImageView *headview = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, (self.view.frame.size.width-20)/2, self.view.frame.size.height/2)];
    

    
    NSLog(@"%@",[map objectForKey:@"coverImg"]);
    
    NSURL *photourl = [NSURL URLWithString:[map objectForKey:@"coverImg"]];
    
    [headview sd_setImageWithURL:photourl];
    
    
    
    

    
    for (id subView in cell.contentView.subviews) {
        [subView removeFromSuperview];
    }

    [cell.contentView addSubview:headview];
    [cell.contentView addSubview:label];
    cell.layer.cornerRadius = 8;
    cell.layer.masksToBounds = YES;
    return cell;
}

#pragma mark --UICollectionViewDelegateFlowLayout

//定义每个Item 的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake((self.view.frame.size.width-20)/2, self.view.frame.size.height/2);
}

//定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(5, 5, 5, 5);
}

#pragma mark --UICollectionViewDelegate

//UICollectionView被选中时调用的方法
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell * cell = (UICollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
    //临时改变个颜色，看好，只是临时改变的。如果要永久改变，可以先改数据源，然后在cellForItemAtIndexPath中控制。（和UITableView差不多吧！O(∩_∩)O~）
    cell.backgroundColor = [UIColor greenColor];
    NSLog(@"item======%d",indexPath.item);
    NSLog(@"row=======%d",indexPath.row);
    NSLog(@"section===%d",indexPath.section);
    NSMutableDictionary *map =  _arrays[indexPath.row];
    NSLog(@"内容 %@",[map objectForKey:@"name"]);
    
    SecondViewController *next =[[SecondViewController alloc]init];
    [next setStr:[map objectForKey:@"name"]];
    [next setTopItem:map];
    
    [self.navigationController pushViewController:next animated:YES];
    
}

//返回这个UICollectionView是否可以被选择
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}




- (void)dealloc
{
    XBLog(@"XBCollectionViewController delloc");
    
}

- (void)setXBParam:(NSString *)XBParam
{
    _XBParam = XBParam;
    XBLog(@"XBCollectionViewController received param === %@",XBParam);
}

@end
