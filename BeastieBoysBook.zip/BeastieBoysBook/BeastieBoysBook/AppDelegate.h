//
//  AppDelegate.h
//  BeastieBoysBook
//
//  Created by  杨兴  on 15/9/20.
//  Copyright (c) 2015年 yx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

