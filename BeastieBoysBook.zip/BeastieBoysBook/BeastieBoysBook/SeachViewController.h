//
//  SeachViewController.h
//  BeastieBoysBook
//
//  Created by  杨兴  on 15/9/24.
//  Copyright © 2015年 yx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SeachViewController : UIViewController<UISearchBarDelegate>


@property (nonatomic,retain) UISearchBar* searchBar;

@property (nonatomic,copy) NSString *XBParam;

@property (nonatomic, strong)UIPanGestureRecognizer *panGestureRecognizer;  

@end
