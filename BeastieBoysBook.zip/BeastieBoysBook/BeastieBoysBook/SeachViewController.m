//
//  SeachViewController.m
//  BeastieBoysBook
//
//  Created by  杨兴  on 15/9/24.
//  Copyright © 2015年 yx. All rights reserved.
//

#import "SeachViewController.h"
#import "XBConst.h"
#import "OneViewController.h"
@interface SeachViewController ()

@end

@implementation SeachViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _searchBar = [[UISearchBar alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width,self.view.frame.size.height/5)];
    _searchBar.placeholder = @"火影忍者";   //设置占位符
    _searchBar.delegate = self;   //设置控件代理
    _searchBar.backgroundColor = [UIColor blackColor];
    //[[_searchBar.subviews objectAtIndex:0]removeFromSuperview];
    
    //2.
    
    for (UIView *subview in _searchBar.subviews)
        
    {
        
        if ([subview isKindOfClass:NSClassFromString(@"UISearchBarBackground")])
            
        {
            
            [subview removeFromSuperview];
            
            break;
            
        }
    [self.view addSubview:_searchBar];
    }
    
  
    
    //单击
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]   initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
    self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
    
    // Do any additional setup after loading the view.
}

-(void) dismissKeyboard{
    NSLog(@"ss");
    [_searchBar resignFirstResponder];

}


- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{

    [_searchBar resignFirstResponder];
    
    OneViewController *o=[[OneViewController alloc]init];
    NSMutableDictionary *map= [NSMutableDictionary dictionary];
    [map setObject:_searchBar.text forKey:@"name"];
    [o setMap:map];
    [self.navigationController pushViewController:o animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

-(void)viewDidAppear:(BOOL)animated {

}



//- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
//    NSLog(@"search clicked");
//}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (void)dealloc
{
    XBLog(@"XBCollectionViewController delloc");
    
}

//(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
//    if (![myTextView isExclusiveTouch]) {
//        [myTextView resignFirstResponder];
//    }
//}


- (void)setXBParam:(NSString *)XBParam
{
    _XBParam = XBParam;
    XBLog(@"XBCollectionViewController received param === %@",XBParam);
}
@end
