//
//  XBConst.m
//  XBScrollPageController
//
//  Created by Scarecrow on 15/9/6.
//  Copyright (c) 2015年 xiu8. All rights reserved.
//

#import "XBConst.h"

NSString *const kTagCollectionViewCellIdentifier = @"kTagCollectionViewCellIdentifier";
NSString *const kPageCollectionViewCellIdentifier = @"kPageCollectionViewCellIdentifier";
NSString *const kCachedTime = @"kCachedTime";
NSString *const kCachedVCName = @"kCachedVCName";
CGFloat const kSelectionIndicatorHeight = 2;