//
//  XBPageCell.h
//  XBScrollPageController
//
//  Created by Scarecrow on 15/9/6.
//  Copyright (c) 2015年 xiu8. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XBPageCell : UICollectionViewCell
- (void)configCellWithController:(UIViewController *)controller;
@end
