//
//  OneViewController.h
//  BeastieBoysBook
//
//  Created by  杨兴  on 15/9/20.
//  Copyright (c) 2015年 yx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OneViewController : UICollectionViewController<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property (nonatomic,copy) NSString *XBParam;
@property (nonatomic,copy) NSMutableArray *arrays;
@property (nonatomic,copy) NSMutableDictionary *map;
@property (strong, nonatomic)UICollectionView *collectionView;

@end
