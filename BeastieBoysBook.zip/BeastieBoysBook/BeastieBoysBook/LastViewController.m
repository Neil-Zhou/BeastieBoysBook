//
//  LastViewController.m
//  BeastieBoysBook
//
//  Created by  杨兴  on 15/9/22.
//  Copyright (c) 2015年 yx. All rights reserved.
//

#import "LastViewController.h"
#import "JHOpenidSupplier.h"
#import "JHAPISDK.h"
#import "UIImageView+WebCache.h"

@interface LastViewController ()

@end

@implementation LastViewController

@synthesize array;
@synthesize maps;


- (instancetype)init{
    
    UICollectionViewFlowLayout *flow = [[UICollectionViewFlowLayout alloc] init];
    flow.minimumLineSpacing = 0;
    flow.minimumInteritemSpacing = 0;
    CGFloat width = [[UIScreen mainScreen] bounds].size.width / 2 - 3*10;
    flow.itemSize = CGSizeMake(width,width);
    flow.sectionInset = UIEdgeInsetsMake(0, 0, 0, 0);
    
    self = [self initWithCollectionViewLayout:flow];
    if (self) {
        // insert code here...
    }
    return self;
}


- (void)reloadDates
{
    //    ***************** LIFE ***************
    //    /*IP*/
    NSString *path = @"http://japi.juhe.cn/comic/chapterContent";
    NSString *api_id = @"163";
    NSString *method = @"GET";
    NSDictionary *param = @{@"comicName":[maps objectForKey:@"comicName"], @"id": [maps objectForKey:@"id"]};
    JHAPISDK *juheapi = [JHAPISDK shareJHAPISDK];
    
    [juheapi executeWorkWithAPI:path
                          APIID:api_id
                     Parameters:param
                         Method:method
                        Success:^(id responseObject){
                            NSLog(@"%@",responseObject);
                            NSDictionary* dic  = responseObject;
                            array= [[dic objectForKey:@"result"] objectForKey:@"imageList"];
                            NSLog(@"%@",array);
                            
                            self.collectionView.reloadData;
                            
                            
                        } Failure:^(NSError *error) {
                            NSLog(@"error:   %@",error.description);
                        }];
}

- (void)viewDidLoad {
    
    UIBarButtonItem *barBtn2=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemCamera target:self action:@selector(changeColor2)];
//    UIBarButtonItem *barBtn3=[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"logo-40@2x.png"] style:UIBarButtonItemStylePlain target:self action:@selector(changeColor3)];
  UIView *view4=[[UIView alloc]initWithFrame:CGRectMake(10, 10, 20, 20)];
//    view4.backgroundColor=[UIColor blackColor];
    UIBarButtonItem *barBtn4=[[UIBarButtonItem alloc]initWithCustomView:view4];
    NSArray *arr1=[[NSArray alloc]initWithObjects:barBtn2,barBtn4, nil];//barBtn3,barBtn4, nil];
    
                   self.navigationItem.rightBarButtonItems=arr1;
    
    
    
    self.view.backgroundColor = [UIColor whiteColor];
    NSLog(@"last page ==%@",[maps objectForKey:@"id"]);
    array = [NSMutableArray array];
    NSLog(@"last page ==%@",maps);
    //    [_arrays addObject:@"你好"];
    //    [_arrays addObject:@"你好"];
    //    [_arrays addObject:@"你好"];
    
    
    [super viewDidLoad];
    
    //确定是水平滚动，还是垂直滚动
    UICollectionViewFlowLayout *flowLayout=[[UICollectionViewFlowLayout alloc] init];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
    
    self.collectionView=[[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) collectionViewLayout:flowLayout];
    self.collectionView.dataSource=self;
    self.collectionView.delegate=self;
    [self.collectionView setBackgroundColor:[UIColor whiteColor]];
    
    //注册Cell，必须要有
    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"UICollectionViewCell"];
    
    [self.view addSubview:self.collectionView];
    [self reloadDates];
    //透明效果 不过所有界面都会透明
//    [self.navigationController.navigationBar setBackgroundImage:[[UIImage alloc] init] forBarMetrics:UIBarMetricsDefault];
//    [self.navigationController.navigationBar setShadowImage:[[UIImage alloc] init]];
//    [self.navigationController.navigationBa

    
}

//}
//定义展示的UICollectionViewCell的个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return array.count;
}

//定义展示的Section的个数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

//-(void) changeColor2{
//
//    NSLog(@"ss");   
//
//}

-(void)changeColor2{
    
    UIGraphicsBeginImageContext(self.view.bounds.size); //currentView 当前的view
    
    [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage *viewImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    UIImageWriteToSavedPhotosAlbum(viewImage, nil, nil, nil);  //保存到相册中
//    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    
}


//每个UICollectionView展示的内容
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * CellIdentifier = @"UICollectionViewCell";
    UICollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    
    NSMutableDictionary *map =  array[indexPath.row];
    
    UIImageView *headview = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    NSURL *photourl = [NSURL URLWithString:[map objectForKey:@"imageUrl"]];
    [headview sd_setImageWithURL:photourl];
    headview.backgroundColor =[UIColor whiteColor];
    
    for (id subView in cell.contentView.subviews) {
        [subView removeFromSuperview];
    }
    [cell.contentView addSubview:headview];
    cell.contentView.backgroundColor = [UIColor whiteColor];
    return cell;
}

#pragma mark --UICollectionViewDelegateFlowLayout

//定义每个Item 的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(self.view.frame.size.width, self.view.frame.size.height);
}

//定义每个UICollectionView 的 margin
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0,0,0,0);
}

#pragma mark --UICollectionViewDelegate

//UICollectionView被选中时调用的方法
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell * cell = (UICollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
    //临时改变个颜色，看好，只是临时改变的。如果要永久改变，可以先改数据源，然后在cellForItemAtIndexPath中控制。（和UITableView差不多吧！O(∩_∩)O~）
    cell.backgroundColor = [UIColor grayColor];
    NSLog(@"item======%d",indexPath.item);
    NSLog(@"row=======%d",indexPath.row);
    NSLog(@"section===%d",indexPath.section);
    NSMutableDictionary *map =  array[indexPath.row];

    
}

//返回这个UICollectionView是否可以被选择
-(BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}


@end
