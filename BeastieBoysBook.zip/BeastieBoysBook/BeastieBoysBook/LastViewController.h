//
//  LastViewController.h
//  BeastieBoysBook
//
//  Created by  杨兴  on 15/9/22.
//  Copyright (c) 2015年 yx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LastViewController : UICollectionViewController<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>


@property NSMutableDictionary *maps;

@property NSMutableArray *array;

@property (strong, nonatomic)UICollectionView *collectionView;

@end
